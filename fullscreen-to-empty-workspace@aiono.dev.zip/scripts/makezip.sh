#!/bin/sh

NAME=fullscreen-to-empty-workspace@aiono.dev
cd $NAME
zip -r $NAME.zip *
mkdir ../build
mv $NAME.zip ../build/$NAME.zip
cd ..

