# Fullscreen to Empty Workspacee
New, maximized and fullscreen windows will be moved to empty workspaces. The extension provides options to configure what types of windows should be moved. Supports multiple monitors.

## Credits
Forked from https://github.com/kaiseracm/gnome-shell-extension-maximize-to-empty-workspace

